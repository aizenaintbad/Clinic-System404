"""Campus Clinic System - Flask + SQLite. Run: python app.py"""
import sqlite3
from flask import Flask, g, jsonify, request

DB = "clinic.db"
app = Flask(__name__, static_folder="static", static_url_path="")

SCHEMA = """
CREATE TABLE IF NOT EXISTS patients(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_no TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  course TEXT, phone TEXT, allergies TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS visits(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  complaint TEXT NOT NULL, diagnosis TEXT, treatment TEXT,
  visit_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS medicines(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL, stock INTEGER NOT NULL DEFAULT 0, unit TEXT DEFAULT 'pcs');
"""

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()

def rows(sql, args=()):
    return [dict(r) for r in db().execute(sql, args).fetchall()]

def run(sql, args=()):
    cur = db().execute(sql, args)
    db().commit()
    return cur.lastrowid

def init_db():
    con = sqlite3.connect(DB)
    con.executescript(SCHEMA)
    if not con.execute("SELECT 1 FROM medicines").fetchone():
        con.executemany("INSERT INTO medicines(name,stock,unit) VALUES(?,?,?)",
            [("Paracetamol 500mg", 120, "tabs"), ("Ibuprofen 200mg", 60, "tabs"),
             ("Cetirizine 10mg", 40, "tabs"), ("Oral Rehydration Salts", 25, "sachets")])
    con.commit(); con.close()

def err(msg, code=400):
    return jsonify(error=msg), code

@app.get("/")
def index():
    return app.send_static_file("index.html")

@app.get("/api/stats")
def stats():
    one = lambda s: db().execute(s).fetchone()[0]
    return jsonify(
        patients=one("SELECT COUNT(*) FROM patients"),
        today=one("SELECT COUNT(*) FROM visits WHERE date(visit_at)=date('now','localtime')"),
        low=one("SELECT COUNT(*) FROM medicines WHERE stock<=10"),
        recent=rows("""SELECT v.id, p.name, v.complaint, v.visit_at FROM visits v
                       JOIN patients p ON p.id=v.patient_id ORDER BY v.id DESC LIMIT 5"""))

@app.route("/api/patients", methods=["GET", "POST"])
def patients():
    if request.method == "GET":
        q = f"%{request.args.get('q', '')}%"
        return jsonify(rows("SELECT * FROM patients WHERE name LIKE ? OR student_no LIKE ? ORDER BY name", (q, q)))
    d = request.get_json(force=True)
    if not d.get("student_no") or not d.get("name"):
        return err("Student number and name are required.")
    try:
        run("INSERT INTO patients(student_no,name,course,phone,allergies) VALUES(?,?,?,?,?)",
            (d["student_no"].strip(), d["name"].strip(), d.get("course"), d.get("phone"), d.get("allergies")))
    except sqlite3.IntegrityError:
        return err("This student number is already registered.")
    return jsonify(ok=True), 201

@app.delete("/api/patients/<int:pid>")
def del_patient(pid):
    run("DELETE FROM patients WHERE id=?", (pid,))
    return jsonify(ok=True)

@app.route("/api/visits", methods=["GET", "POST"])
def visits():
    if request.method == "GET":
        return jsonify(rows("""SELECT v.*, p.name, p.student_no, p.allergies FROM visits v
                               JOIN patients p ON p.id=v.patient_id ORDER BY v.id DESC"""))
    d = request.get_json(force=True)
    if not d.get("patient_id") or not d.get("complaint"):
        return err("Patient and complaint are required.")
    run("INSERT INTO visits(patient_id,complaint,diagnosis,treatment) VALUES(?,?,?,?)",
        (d["patient_id"], d["complaint"], d.get("diagnosis"), d.get("treatment")))
    return jsonify(ok=True), 201

@app.route("/api/medicines", methods=["GET", "POST"])
def medicines():
    if request.method == "GET":
        return jsonify(rows("SELECT * FROM medicines ORDER BY name"))
    d = request.get_json(force=True)
    if not d.get("name"):
        return err("Medicine name is required.")
    try:
        run("INSERT INTO medicines(name,stock,unit) VALUES(?,?,?)",
            (d["name"].strip(), int(d.get("stock") or 0), d.get("unit") or "pcs"))
    except sqlite3.IntegrityError:
        return err("That medicine already exists.")
    return jsonify(ok=True), 201

@app.patch("/api/medicines/<int:mid>")
def adjust(mid):
    delta = int(request.get_json(force=True).get("delta", 0))
    run("UPDATE medicines SET stock=MAX(0, stock+?) WHERE id=?", (delta, mid))
    return jsonify(ok=True)

@app.delete("/api/medicines/<int:mid>")
def del_med(mid):
    run("DELETE FROM medicines WHERE id=?", (mid,))
    return jsonify(ok=True)

if __name__ == "__main__":
    init_db()  # database and tables are created automatically
    app.run(debug=True)
