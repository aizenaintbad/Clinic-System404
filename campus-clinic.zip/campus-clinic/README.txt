Campus Clinic System
1) pip install -r requirements.txt
2) python app.py
3) Open http://127.0.0.1:5000
The SQLite file (clinic.db) and tables are created automatically on first run.
